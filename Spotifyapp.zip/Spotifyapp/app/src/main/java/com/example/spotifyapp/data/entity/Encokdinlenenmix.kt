package com.example.spotifyapp.data.entity

import java.io.Serializable

data class Encokdinlenenmix(var id:Int,var ad:String,var resim:String) :Serializable{
}