package com.example.spotifyapp.data.entity

import java.io.Serializable

data class Playlist (var id:Int,var ad:String,var resim:String):Serializable{
}