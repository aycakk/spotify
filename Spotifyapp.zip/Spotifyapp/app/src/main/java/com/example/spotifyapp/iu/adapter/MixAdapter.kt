package com.example.spotifyapp.iu.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.spotifyapp.data.entity.Encokdinlenenmix
import com.example.spotifyapp.databinding.CardTasarimBinding
import com.example.spotifyapp.databinding.EncokmixTasarimBinding

class MixAdapter(var mcontext:Context,var encokdinlenenmix:List <Encokdinlenenmix>) :RecyclerView.Adapter<MixAdapter.EnCokMixTasarimTutucu>() {

    inner class EnCokMixTasarimTutucu(var tasarim: EncokmixTasarimBinding): RecyclerView.ViewHolder(tasarim.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MixAdapter.EnCokMixTasarimTutucu{
        val binding=EncokmixTasarimBinding.inflate(LayoutInflater.from(mcontext),parent,false)
        return EnCokMixTasarimTutucu(binding)
    }


    override fun onBindViewHolder(holder: MixAdapter.EnCokMixTasarimTutucu, position: Int) {
        val mix=encokdinlenenmix.get(position)
        val t=holder.tasarim
       t.imageViewmix.setImageResource(mcontext.resources.getIdentifier(mix.resim,"drawable",mcontext.packageName))
        t.textViewmixad.text="${mix.ad}"
        t.textViewaciklama.text="${mix.ad}"

    }
    override fun getItemCount(): Int {
        return encokdinlenenmix.size
    }


}