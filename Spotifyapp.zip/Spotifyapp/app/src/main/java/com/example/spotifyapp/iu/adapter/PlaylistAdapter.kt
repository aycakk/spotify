package com.example.spotifyapp.iu.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.spotifyapp.data.entity.Playlist
import com.example.spotifyapp.databinding.CardTasarimBinding

class PlaylistAdapter(var mcontext: Context,var playlist:List<Playlist>)
    :RecyclerView.Adapter<PlaylistAdapter.CardTasarimTutucu>()
{
    inner class CardTasarimTutucu(var tasarim:CardTasarimBinding):RecyclerView.ViewHolder(tasarim.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimTutucu {
        val binding=CardTasarimBinding.inflate(LayoutInflater.from(mcontext),parent,false)
        return CardTasarimTutucu(binding)

    }



    override fun onBindViewHolder(holder: CardTasarimTutucu, position: Int) {
        val playlist=playlist.get(position)
        val t=holder.tasarim
        t.imageViewplaylist.setImageResource(mcontext.resources.getIdentifier(playlist.resim,"drawable",mcontext.packageName))
        t.playlistaciklama.text="${playlist.ad}"

    }

    override fun getItemCount(): Int {
        return playlist.size
    }


}