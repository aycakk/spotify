package com.example.spotifyapp.iu.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.spotifyapp.R
import com.example.spotifyapp.data.entity.Encokdinlenenmix
import com.example.spotifyapp.data.entity.Playlist
import com.example.spotifyapp.databinding.FragmentAnasayfaBinding
import com.example.spotifyapp.iu.adapter.MixAdapter
import com.example.spotifyapp.iu.adapter.PlaylistAdapter

class AnasayfaFragment : Fragment() {
    private lateinit var binding: FragmentAnasayfaBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentAnasayfaBinding.inflate(inflater, container, false)
        binding.playlistrv.layoutManager= StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        val playlist=ArrayList<Playlist>()
        val p1=Playlist(1,"Peaches","resim1")
        val p2=Playlist(1,"Yol şarkıları","resim2")
        val p3=Playlist(1,"Romantik","resim3")
        val p4=Playlist(1,"Bale","resim4")
        val p5=Playlist(1,"Uyumadan Önce","resim5")
        val p6=Playlist(1,"Latin","resim6")
        val p7=Playlist(1,"Kpop","resim7")
        val p8=Playlist(1,"Dance","resim8")
        playlist.add(p1)
        playlist.add(p2)
        playlist.add(p3)
        playlist.add(p4)
        playlist.add(p5)
        playlist.add(p6)
        playlist.add(p7)
        playlist.add(p8)
        val playlists=PlaylistAdapter(requireContext(),playlist)
        binding.playlistrv.adapter=playlists



        val mixlist=ArrayList<Encokdinlenenmix>()
        val m1=Encokdinlenenmix(1,"Harry Styles","encok1")
        val m2=Encokdinlenenmix(2,"JungKook","encok2")
        val m3=Encokdinlenenmix(3,"Lana Del REY","encok3")
        val m4=Encokdinlenenmix(1,"jennie","encok4")
        val m5=Encokdinlenenmix(1,"Dolu Kadehi Ters Tut","encok5")
        mixlist.add(m1)
        mixlist.add(m2)
        mixlist.add(m3)
        mixlist.add(m4)
        mixlist.add(m5)
        binding.mixrv.layoutManager=StaggeredGridLayoutManager(1,StaggeredGridLayoutManager.HORIZONTAL)
        val mixlistt=MixAdapter(requireContext(),mixlist)
        binding.mixrv.adapter=mixlistt













        return binding.root
    }


}